# Log Analyzer (Python)

A command-line tool that parses application log files and surfaces the patterns that matter during support and incident triage: counts by log level, the most frequent error/warning messages, and the time range covered — without needing to scroll through thousands of lines by hand.

## How it works

1. Each log line is matched against an expected format (`timestamp level message`) using a regular expression.
2. Entries are grouped by level (`INFO`, `WARNING`, `ERROR`, `CRITICAL`, etc.).
3. Similar messages (e.g. the same error with different details) are grouped so repeated issues stand out instead of being buried as separate lines.

No external dependencies — it runs with the Python standard library only.

## Setup

```bash
git clone https://github.com/W0danOfnir/log-analyzer-python.git
cd log-analyzer-python
```

## Usage

**Summarize an entire log file:**

```bash
python log_analyzer.py sample_logs/app.log
```

Example output:

```
Parsed 20 log entries

Entries by level:
  INFO       8
  WARNING    4
  ERROR      5
  CRITICAL   3

Top Critical messages:
  [3x] Database connection pool exhausted

Top Error messages:
  [3x] Failed to connect to payment gateway
  [1x] NullReferenceException in OrderProcessor.processOrder()

Time range covered: 2026-07-18 09:12:03 -> 2026-07-18 09:45:00
```

**Filter to a specific log level:**

```bash
python log_analyzer.py sample_logs/app.log --level ERROR
```

**Control how many top messages are shown per level:**

```bash
python log_analyzer.py sample_logs/app.log --top 5
```

## Project structure

```
log-analyzer-python/
├── log_analyzer.py         # parsing + analysis CLI
├── sample_logs/
│   └── app.log             # example log file
├── requirements.txt
└── README.md
```

## Extending this project

- Adjust `LOG_PATTERN` in `log_analyzer.py` to match your own log format (e.g. JSON logs, or a different timestamp format).
- Add an `--export csv` option to write the summary out for reporting.
- Add anomaly detection (e.g. flag when error counts spike above a rolling average).

## Why this project

Log triage is a recurring part of technical/developer support work — spotting the handful of messages that actually matter in a wall of text. This tool automates the first pass of that process.
