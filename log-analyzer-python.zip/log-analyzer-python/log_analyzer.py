"""
Log Analyzer
------------
Parses application log files and surfaces useful patterns: counts by log
level, the most frequent error/warning messages, and a simple timeline of
critical events - built to cut down the manual scanning that often happens
during support/incident triage.

Usage:
    python log_analyzer.py sample_logs/app.log
    python log_analyzer.py sample_logs/app.log --level ERROR
    python log_analyzer.py sample_logs/app.log --top 5
"""

import argparse
import re
from collections import Counter, defaultdict
from pathlib import Path

LOG_PATTERN = re.compile(
    r"^(?P<timestamp>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\s+"
    r"(?P<level>DEBUG|INFO|WARNING|ERROR|CRITICAL)\s+"
    r"(?P<message>.+)$"
)

LEVEL_ORDER = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]


def parse_log(path: Path):
    entries = []
    unmatched = 0
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line.strip():
                continue
            match = LOG_PATTERN.match(line)
            if match:
                entries.append(match.groupdict())
            else:
                unmatched += 1
    return entries, unmatched


def summarize(entries):
    level_counts = Counter(e["level"] for e in entries)
    messages_by_level = defaultdict(Counter)
    for e in entries:
        # Normalize messages slightly so near-duplicates (e.g. with a
        # trailing stack trace line) still group together.
        key = e["message"].split(":")[0].strip()
        messages_by_level[e["level"]][key] += 1
    return level_counts, messages_by_level


def print_summary(entries, level_counts, messages_by_level, top_n: int = 3):
    total = len(entries)
    print(f"Parsed {total} log entries\n")

    print("Entries by level:")
    for level in LEVEL_ORDER:
        if level in level_counts:
            print(f"  {level:<10} {level_counts[level]}")
    print()

    for level in ["CRITICAL", "ERROR", "WARNING"]:
        if level not in messages_by_level:
            continue
        print(f"Top {level.title()} messages:")
        for message, count in messages_by_level[level].most_common(top_n):
            print(f"  [{count}x] {message}")
        print()

    if entries:
        first, last = entries[0]["timestamp"], entries[-1]["timestamp"]
        print(f"Time range covered: {first} -> {last}")


def filter_by_level(entries, level: str):
    level = level.upper()
    return [e for e in entries if e["level"] == level]


def main():
    parser = argparse.ArgumentParser(description="Analyze an application log file.")
    parser.add_argument("logfile", type=str, help="Path to the log file to analyze.")
    parser.add_argument("--level", type=str, help="Only show entries matching this log level (e.g. ERROR).")
    parser.add_argument("--top", type=int, default=3, help="Number of top messages to show per level (default: 3).")
    args = parser.parse_args()

    path = Path(args.logfile)
    if not path.exists():
        print(f"File not found: {path}")
        return

    entries, unmatched = parse_log(path)
    if unmatched:
        print(f"Note: skipped {unmatched} line(s) that didn't match the expected log format.\n")

    if args.level:
        filtered = filter_by_level(entries, args.level)
        print(f"{len(filtered)} entries at level {args.level.upper()}:\n")
        for e in filtered:
            print(f"  {e['timestamp']}  {e['message']}")
        return

    level_counts, messages_by_level = summarize(entries)
    print_summary(entries, level_counts, messages_by_level, top_n=args.top)


if __name__ == "__main__":
    main()
