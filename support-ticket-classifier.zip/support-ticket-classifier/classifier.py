"""
Support Ticket Classifier
--------------------------
Trains a text classification model to automatically categorize support
tickets (e.g. bug, account, billing, documentation, integration), and lets
you classify new ticket text from the command line.

Usage:
    Train and evaluate on the bundled sample data:
        python classifier.py --train

    Classify a new ticket:
        python classifier.py --predict "My app crashes when I tap login"
"""

import argparse
import csv
import pickle
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report

DATA_PATH = Path(__file__).parent / "data" / "sample_tickets.csv"
MODEL_PATH = Path(__file__).parent / "model.pkl"


def load_data(path: Path = DATA_PATH):
    texts, labels = [], []
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            texts.append(row["text"])
            labels.append(row["category"])
    return texts, labels


def build_pipeline() -> Pipeline:
    return Pipeline([
        ("tfidf", TfidfVectorizer(stop_words="english", ngram_range=(1, 2))),
        ("clf", LogisticRegression(max_iter=1000)),
    ])


def train(save: bool = True) -> Pipeline:
    texts, labels = load_data()
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=0.25, random_state=42, stratify=labels
    )

    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)

    preds = pipeline.predict(X_test)
    print("Evaluation on held-out test split:\n")
    print(classification_report(y_test, preds, zero_division=0))

    if save:
        with open(MODEL_PATH, "wb") as f:
            pickle.dump(pipeline, f)
        print(f"Model saved to {MODEL_PATH}")

    return pipeline


def load_model() -> Pipeline:
    if not MODEL_PATH.exists():
        print("No trained model found - training one now on the sample data...")
        return train()
    with open(MODEL_PATH, "rb") as f:
        return pickle.load(f)


def predict(text: str) -> str:
    pipeline = load_model()
    prediction = pipeline.predict([text])[0]
    probabilities = pipeline.predict_proba([text])[0]
    classes = pipeline.classes_
    ranked = sorted(zip(classes, probabilities), key=lambda x: x[1], reverse=True)

    print(f"\nTicket: {text!r}")
    print(f"Predicted category: {prediction}\n")
    print("Confidence breakdown:")
    for label, prob in ranked:
        print(f"  {label:<15} {prob:.2%}")

    return prediction


def main():
    parser = argparse.ArgumentParser(description="Classify support tickets by category.")
    parser.add_argument("--train", action="store_true", help="Train and evaluate the model on sample data.")
    parser.add_argument("--predict", type=str, metavar="TEXT", help="Classify a single piece of ticket text.")
    args = parser.parse_args()

    if args.train:
        train()
    elif args.predict:
        predict(args.predict)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
