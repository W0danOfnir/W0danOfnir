# Support Ticket Classifier

A lightweight machine learning tool that automatically categorizes support tickets by type — `bug`, `account`, `billing`, `documentation`, or `integration` — using text classification. Built to speed up triage in high-volume support queues by routing tickets to the right category (and team) automatically.

## How it works

The classifier uses a **TF-IDF + Logistic Regression** pipeline (via scikit-learn):

1. Ticket text is converted into weighted word/bigram features with `TfidfVectorizer`.
2. A `LogisticRegression` classifier is trained on labeled example tickets.
3. New tickets are classified with a predicted category plus a confidence breakdown across all categories.

## Setup

```bash
git clone https://github.com/W0danOfnir/support-ticket-classifier.git
cd support-ticket-classifier
pip install -r requirements.txt
```

## Usage

**Train and evaluate the model** on the bundled sample dataset (`data/sample_tickets.csv`):

```bash
python classifier.py --train
```

This prints a precision/recall/F1 report on a held-out test split and saves the trained model to `model.pkl`.

**Classify a new ticket:**

```bash
python classifier.py --predict "My app crashes every time I tap login"
```

Example output:

```
Ticket: 'My app crashes every time I tap login'
Predicted category: bug

Confidence breakdown:
  bug             81.42%
  integration     9.87%
  account         5.21%
  documentation   2.13%
  billing         1.37%
```

## Project structure

```
support-ticket-classifier/
├── classifier.py           # training + prediction CLI
├── data/
│   └── sample_tickets.csv  # example labeled tickets
├── requirements.txt
└── README.md
```

## Extending this project

- Swap in your own labeled ticket data in `data/` (same `text,category` CSV format) to train on real tickets.
- Try a different model (e.g. `LinearSVC`, or a transformer-based classifier) by editing `build_pipeline()` in `classifier.py`.
- Add a small Flask/FastAPI wrapper around `predict()` to expose this as a service.

## Why this project

This started as a way to combine two parts of my background: years of hands-on developer/technical support work, and a growing focus on applied machine learning. Ticket classification is a small but real example of where ML can directly reduce manual triage time in a support workflow.
